//
//  LoginViewController.swift
//  ToGo
//
//  Created by Norah on 2/23/16.
//  Copyright © 2016 Norah. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {
    /*@IBOutlet weak var toggleSingupButton: UIButton!*/
    /*@IBAction func toggleSingup(sender: AnyObject) {}*/

    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var retrieve: UIButton!
    
    @IBOutlet weak var switchSPC: UISwitch!
    
    @IBOutlet weak var consumerLabel: UILabel!
    @IBOutlet weak var spLabel: UILabel!
    
    @IBOutlet weak var singUpButton: UIButton!
    @IBOutlet weak var logInButton: UIButton!
    
    
    @IBAction func switchType(sender: UISwitch) {
        if switchSPC.on{
            spLabel.textColor=UIColor.blueColor()
            consumerLabel.textColor=UIColor.blackColor()
            userName.keyboardType = .EmailAddress
            
            userName.placeholder="Email"
            //password.hidden=false
            //retrieve.hidden=false
        }else{
            consumerLabel.textColor=UIColor.blueColor()
            spLabel.textColor=UIColor.blackColor()
            userName.keyboardType = .NumberPad
            
            userName.placeholder="Phone No."
            //password.hidden=true
            //retrieve.hidden=true
        }
    }
    
    @IBAction func singUp(sender: AnyObject) {
        
        
    }
    
    @IBAction func logIn(sender: AnyObject) {
        var valid=false;
        var message="";
        //validation if Empty?
    if userName.text == "" || password.text == "" {
            displayAlert("Missing field(s)", message: "Some fields are not correct!")
    }else{
        //validation (Format Email, Phone No)
            if switchSPC.on{
                valid=validateEmail(userName.text!)
                message="Incorrect Email"
            }else{
                valid=validatePhone(userName.text!)
                message="Incorrect Phone"
            }
            
            //if valid. go Log in
            if valid {
                //Log in code here
                
                let myUrl = NSURL(string: "http://thetogo.net/Login/Login.php");
                let request = NSMutableURLRequest(URL:myUrl!);
                request.HTTPMethod = "POST";
                // Compose a query string
                   // For SP
                var postString = "email="+userName.text!+"&password="+password.text!+"&phone=None";
                   // For Customer
                if message=="Incorrect Phone"{
                postString = "phone="+userName.text!+"&password="+password.text!+"&email=None";
                }
                
                request.HTTPBody = postString.dataUsingEncoding(NSUTF8StringEncoding)
                
                let task = NSURLSession.sharedSession().dataTaskWithRequest(request){
                    data, response, error in
                    
                    if error != nil
                    {
                        print("error=\(error)")
                        return
                    }
                    
                //IF the connection Succeeded
                    do{
                        let myJSON=try NSJSONSerialization.JSONObjectWithData(data!, options: .MutableLeaves) as? NSDictionary
                        
                        if let parseJSON=myJSON {
                            let resultValue = parseJSON["status"] as! String
                            print("resulat: \(resultValue), Message:\(parseJSON["message"])")
                            
                            if(resultValue=="Success"){
                                //Log in Successful
                                NSUserDefaults.standardUserDefaults().setBool(true , forKey: "isUserLoggedIn");
                                NSUserDefaults.standardUserDefaults().synchronize()
                                
                                self.dismissViewControllerAnimated(true, completion: nil)
                                /*if switchSPC.on{
                                  
                                  //Log in to SP Menu
                                
                                }else{
                                
                                  //Log in to C Menu
                                
                                }*/
                            }
                            
                        }
                        
                    }catch let err as NSError {print(err)}
                    
                }
                
                task.resume()

            
            }else{displayAlert("Incorrect Value", message: message)}
    }//End else empty?
    }

    //------------------Oevrride methods--------------************------------------
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.userName.delegate = self;
        self.password.delegate = self;
        //Looks for single or multiple taps.
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        view.addGestureRecognizer(tap)
    }
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //-----------------------------------------------************----------------
    //Alert messages METHOD
    func displayAlert(title:String, message:String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    //active Done button METHOD
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true);
        return false;
    }
    //Email validdation METHOD
    func validateEmail(candidate: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}"
        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluateWithObject(candidate)
    }
    //Phone validation METHOD
    func validatePhone(candidate: String)->  Bool{
        let phoneRegex = "^\\d{10}$"
        return NSPredicate(format: "SELF MATCHES %@", phoneRegex).evaluateWithObject(candidate)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
